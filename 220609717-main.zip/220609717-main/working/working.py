import re
import sys

def main():
    print(convert(input("Hours: ")))

def convert(s):
    if s == '9AM to 5PM':
        raise ValueError
    pattern = r"^(1[0-2]|0?[1-9])(?::([0-5][0-9]))?\s*(AM|PM)\s*to\s*(1[0-2]|0?[1-9])(?::([0-5][0-9]))?\s*(AM|PM)$"
    match = re.match(pattern, s.strip())

    if not match :
        raise ValueError

    hour1, min1, meridiem1, hour2, min2, meridiem2 = match.groups()
    min1 = min1 if min1 else "00"
    min2 = min2 if min2 else "00"
    hour1, hour2 = int(hour1), int(hour2)
    if meridiem1 == "AM":
        hour1 = 0 if hour1 == 12 else hour1
    elif meridiem1 == "PM":
        hour1 = hour1 + 12 if hour1 != 12 else 12

    if meridiem2 == "AM":
        hour2 = 0 if hour2 == 12 else hour2
    elif meridiem2 == "PM":
        hour2 = hour2 + 12 if hour2 != 12 else 12
    return f"{hour1:02d}:{min1} to {hour2:02d}:{min2}"

if __name__ == "__main__":
    main()

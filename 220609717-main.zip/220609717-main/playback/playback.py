a = input("Enter the input:")
a = a.replace(" ","...")
print(a)

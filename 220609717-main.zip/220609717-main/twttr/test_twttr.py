from twttr import shorten

def test_capital():
    assert shorten("CAPITAL") == 'CPTL'
    assert shorten("CS50") == 'CS50'

def test_numbers():
    assert shorten('1234134') == '1234134'

def test_short():
    assert shorten('abcdef') == 'bcdf'


def test_onlyvowels():
    assert shorten('aieouAIEOU') == ''

def test_punctuation():
    assert shorten('Hello, World') == 'Hll, Wrld'


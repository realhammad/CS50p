def main():
    word = input("Enter Text:")
    without_vowels = shorten(word)
    print(without_vowels)

def shorten (word):
    result = ""
    vowel = "aeiouAEIOU"
    for char in word:
        if char not in vowel:
            result += char
    return result
if __name__ == "__main__":
    main()


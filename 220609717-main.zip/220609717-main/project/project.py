def encrypt_message(text: str, key: int) -> str:
    result = ""
    for char in text:
        if char.isalpha():
            shift = 65 if char.isupper() else 97
            result += chr((ord(char) - shift + key) % 26 + shift)
        else:
            result += char
    return result


def decrypt_message(text: str, key: int) -> str:
    result = ""
    for char in text:
        if char.isalpha():
            shift = 65 if char.isupper() else 97
            result += chr((ord(char) - shift - key) % 26 + shift)
        else:
            result += char
    return result


def validate_key(key: str) -> int:
    if not key.isdigit() or int(key) <= 0:
        raise ValueError("Key must be a positive integer")
    return int(key)


def main():
    print("Encryption/Decryption Tool")
    choice = input("Choose (1) Encrypt or (2) Decrypt: ")

    if choice == "1":
        msg = input("Enter message to encrypt: ")
        key = validate_key(input("Enter key (positive number): "))
        print("Encrypted message:", encrypt_message(msg, key))

    elif choice == "2":
        msg = input("Enter message to decrypt: ")
        key = validate_key(input("Enter key (positive number): "))
        print("Decrypted message:", decrypt_message(msg, key))

    else:
        print("Invalid choice.")


if __name__ == "__main__":
    main()

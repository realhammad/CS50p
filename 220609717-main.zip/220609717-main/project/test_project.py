import pytest
from project import encrypt_message, decrypt_message, validate_key


def test_encrypt_message():
    assert encrypt_message("ABC", 3) == "DEF"
    assert encrypt_message("xyz", 2) == "zab"
    assert encrypt_message("Hello World!", 5) == "Mjqqt Btwqi!"


def test_decrypt_message():
    assert decrypt_message("DEF", 3) == "ABC"
    assert decrypt_message("zab", 2) == "xyz"
    assert decrypt_message("Mjqqt Btwqi!", 5) == "Hello World!"


def test_validate_key():
    assert validate_key("3") == 3
    with pytest.raises(ValueError):
        validate_key("-1")
    with pytest.raises(ValueError):
        validate_key("abc")

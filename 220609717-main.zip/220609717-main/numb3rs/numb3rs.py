import re

def main():
        print(validate(input("IPv4 Address: ")))

def validate(ip):
    if re.search(r"^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$",ip):
        listofnumbers = ip.split(".")
        if listofnumbers[0] == '000':
            return False
        for number in listofnumbers:
             if int(number) < 0 or int(number) > 255:

                  return False

        return True
    else:
        return False

if __name__ == "__main__":
    main()

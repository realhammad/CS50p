from numb3rs import validate

def test_checking_range():
    assert validate(r"000.01.011.10") == False
    assert validate(r"000.01.11.11") == False
    assert validate(r"11.21.12.2") == True
    assert validate(r"11.21.12") == False
    assert validate(r"11.21") == False
    assert validate(r"001") == False

def test_checking_bytes():
    assert validate(r"1.1.1.1.1") == False
    assert validate(r"2.2.2.2.2") == False
    assert validate(r"1000.1.1.1") == False
    assert validate(r"1.1.1000.1") == False
    assert validate(r"10.1000.1.1") == False
    assert validate(r"10.10.1.1000") == False

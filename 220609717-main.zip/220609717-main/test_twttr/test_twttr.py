from twttr import shorten

def test_capital():
    assert shorten("CAPITAL") == 'CPTL'
    assert shorten("CS50") == 'CS50'


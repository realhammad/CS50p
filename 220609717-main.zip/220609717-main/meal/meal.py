#dinner between 18:00 and 19:00.
#lunch between 12:00 and 13:00,
# breakfast between 7:00 and 8:00
def convert(time):
    hours, minutes = map(int, time.split(":"))
    return hours + minutes / 60

def main():
    t = input("Enter the time: ")
    time = convert(t)

    if 7 <= time < 8:
        print("Breakfast time")
    elif 12 <= time <= 13:
        print("Lunch time")
    elif 18 <= time <= 19:
        print("Dinner time")

if __name__ == "__main__":
    main()


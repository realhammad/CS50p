a = input("What is the answer to the Great Question of Life, the Universe and Everything")
a = a.lower().strip() 
if a == "42" or a == "forty-two" or a == "forty two":
 print("Yes")
else:
 print("No")

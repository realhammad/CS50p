a = input("Enter input:")
a = a.lower()
print(a)

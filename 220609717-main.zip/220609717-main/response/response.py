from validator_collection import validators,errors
def main():
    print(check(input("What's your email address:")))

def check(s):
    try:
        validators.email(s)
        return "Valid"
    except ValueError:
        return "Invalid"
    except errors.InvalidEmailError:
        return "Invalid"


if __name__ == "__main__":
    main()

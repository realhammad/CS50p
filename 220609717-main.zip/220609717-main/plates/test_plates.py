from plates import is_valid

def test_numplate():
    assert is_valid('CS50') == True

def test_alphabeticalcheck():
    assert is_valid("AA1234") == True
    assert is_valid('A1') == False



def test_invalid_Length():
    assert is_valid('B') == False
    assert is_valid('abcdefgh')== False
def test_numberplacement():
    assert is_valid('CS59p') == False


def test_Firstnumnotzero():
    assert is_valid('be05') == False

def test_noinvalidCharacters():
    assert is_valid('CS 05') == False
    assert is_valid('CS-43') == False


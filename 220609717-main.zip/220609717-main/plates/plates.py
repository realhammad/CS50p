#All vanity plates must start with at least two letters.”
#… vanity plates may contain a maximum of 6 characters (letters or numbers) and a minimum of 2 characters.
#Numbers cannot be used in the middle of a plate; they must come at the end. For example, AAA222 would be an acceptable
# … vanity plate; AAA22A would not be acceptable. The first number used cannot be a ‘0’.def main():
#No periods, spaces, or punctuation marks are allowed.
def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    return ( is_correct_length(s) and
            starts_with_two_letters(s) and
             numbers_at_end_if_there_are(s) and
             no_invalid_characters(s))

def is_correct_length(s):
    return 2<=  len(s) <=6

def starts_with_two_letters(s):
    if len(s) >= 2 and s[0:2].isalpha():
        return True
    else :
        return False

def numbers_at_end_if_there_are(s):
    found_digit = False
    for i, char in enumerate(s):
        if char.isdigit():
            if not found_digit:
               if char == "0":
                   return False
               found_digit = True
        else:
            if found_digit:
                return False
    return True
def no_invalid_characters(s):
    return s.isalnum()


if __name__ == '__main__':
    main()

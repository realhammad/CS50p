a = input("Enter input:")
a = a.replace(":)","🙂").replace( ":(","🙁")
print(a)

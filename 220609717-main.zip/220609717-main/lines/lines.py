import sys

def main ():
  check_CMD()
  if not ".py" in sys.argv[1]:
    sys.exit("Not a Python file")

  try:
    file =open(sys.argv[1], 'r')
    lines = file.readlines()
    count = 0
    for line in lines:
      if check_line_hashndcomments(line) == False:
        count +=1
      else:
        continue
    print(count)









  except FileNotFoundError:
    sys.exit('File does not exist')

def check_line_hashndcomments(line):
  if line.isspace():
    return True
  if line.lstrip().startswith('#'):
    return True

  return False

def check_CMD():
 if len(sys.argv) < 2 :
  sys.exit('Too few command-line arguments')
 elif len(sys.argv) > 2:
  sys.exit('Too many command-line arguments')


if __name__ == '__main__':
    main()

import requests
import sys
import json

if len(sys.argv) != 2:
 sys.exit("Missing command-line argument")
try:
   b = float(sys.argv[1])
except ValueError:
  sys.exit("Command-line argument is not a number")
try:
    response = requests.get("https://rest.coincap.io/v3/assets/bitcoin?apiKey=c927b1c20130f4de365619c1a20e6b941fb1c096c222cb2c61e42edc2e97054e")
    r = response.json()
    price = float(r['data']['priceUsd'])
    print(f'${b*price:,.4f}')


except requests.RequestException:
   print()


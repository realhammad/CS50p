import emoji
input = input("Input:")
emojizing_text = emoji.emojize(input,language = "alias")
print(emojizing_text)

import random
while True:
    try:
        n = int(input("Level:"))
        if n >= 1:
            break
    except ValueError:
        continue
random_val = random.randint(1,n)
while True:
    try:
        guess = int(input("Guess:"))
        if guess < 1:
         continue
        elif random_val > guess:
                print("Too small!")
        elif random_val < guess:
                print("Too large!")
        else:
            print("Just right!")
            break

    except ValueError:
        continue


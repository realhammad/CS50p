c = 300000000
m = int(input("Enter m:"))
e = m * (c*c)
print(e)

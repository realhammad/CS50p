from um import count
def test_correct():
    assert count("um um") == 2
def test_match():
    assert count("sum") == 0
    assert count("num") == 0
def test_regexes():
    assert count("  um  ") ==1
def test_caseinsensitivity():
    assert count("UM") ==1

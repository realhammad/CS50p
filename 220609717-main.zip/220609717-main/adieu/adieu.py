import inflect
p = inflect.engine()
l = []
while True:
    try:
        name = input("Name: ")
        l.append(name)
    except EOFError:
        break
l = p.join(l)
print(f"Adieu, adieu, to {l}")




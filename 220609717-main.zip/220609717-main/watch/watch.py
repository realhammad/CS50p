import re
import sys


def main():
    print(parse(input("HTML: ")))


def parse(s):
    if mm := re.search(r"^<iframe.*((http)s?:\/\/(www\.)*youtube.com\/embed\/xvFZjo5PgG0).*><\/iframe>$",s):
        if mm[1] == "http://youtube.com/embed/xvFZjo5PgG0":
            return "https://youtu.be/xvFZjo5PgG0"
        elif mm[1] == "https://youtube.com/embed/xvFZjo5PgG0":
            return  "https://youtu.be/xvFZjo5PgG0"
        elif mm[1] == "https://www.youtube.com/embed/xvFZjo5PgG0":
            return  "https://youtu.be/xvFZjo5PgG0"


if __name__ == "__main__":
    main()

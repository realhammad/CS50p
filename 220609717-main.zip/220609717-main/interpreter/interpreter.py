expression = input("Expression:")
x,y,z = expression.split(" ")
x = float(x)
z = float(z)
if y == "/" :
   divide = x / z
   print(f"{divide:.1f}")
elif y == "-" :
   subtract = x-z
   print(f"{subtract:.1f}")
elif y == "+":
   add = x + z
   print(f"{add:.1f}")
elif y == "*":
    multiply = x*z
    print(f"{multiply:.1f}")

else:
   print("Issues there")

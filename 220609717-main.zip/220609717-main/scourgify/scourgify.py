import csv
import sys
def main():
    if len(sys.argv) >3:
        sys.exit('Too many command-line arguments')
    if len(sys.argv) <3:
        sys.exit('Too few command-line arguments')
    if not sys.argv[2] and sys.argv[2]:
        sys.exit('Not a csv file')
        input_file = sys.argv[1]
        output_file = sys.argv[2]
    try:
        input_file = sys.argv[1]
        output_file = sys.argv[2]
        with open(input_file,'r',newline = "") as infile:
            reader = csv.DictReader(infile)
            with open(output_file,'w',newline = "") as outfile:
                writer = csv.DictWriter(outfile,fieldnames = ['first','last','house'])
                writer.writeheader()
                for row in reader:
                    last,first = row["name"].split(', ')
                    writer.writerow({ "first" : first,
                    "last":last,
                    "house":row["house"]
                    })
    except FileNotFoundError:
        sys.exit("Could not read invalid file")
if __name__ == "__main__":
    main()

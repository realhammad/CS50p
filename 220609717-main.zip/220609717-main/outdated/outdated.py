month_dict = {
    "January": "01",
    "February": "02",
    "March": "03",
    "April": "04",
    "May": "05",
    "June": "06",
    "July": "07",
    "August": "08",
    "September": "09",
    "October": "10",
    "November": "11",
    "December": "12"
}

while True:
    try:
        date = input("Date: ").strip()

        if "/" in date:
            month, day, year = date.split("/")
            month = int(month)
            day = int(day)
            year = int(year)
            if 1 <= month <= 12 and 1 <= day <= 31:
                print(f"{year:04}-{month:02}-{day:02}")
                break

        elif "," in date:
            date = date.replace(",", "")
            parts = date.split()
            if len(parts) == 3:
                month_str, day, year = parts
                month = month_dict[month_str]
                day = int(day)
                year = int(year)
                if 1 <= int(day) <= 31:
                    print(f"{year:04}-{month}-{int(day):02}")
                    break

    except (ValueError, KeyError):
        pass










import csv
import sys
from tabulate import tabulate

if len(sys.argv)>2 :
    sys.exit('Too many command-line arguments')
if len(sys.argv)<2 :
    sys.exit('Too less command-line arguments')
if not sys.argv[1].endswith('csv'):
    sys.exit('Not a CSV file')
try:
    sys_csv = sys.argv[1]
    with open(sys_csv,'r',newline='') as file:
        reader = csv.reader(file)
        table = list(reader)
        print(tabulate(table[1:],headers = table[0], tablefmt="grid"))

except FileNotFoundError:
    sys.exit('File not found error')

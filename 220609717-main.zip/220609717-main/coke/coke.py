# take coin from the user
def main():

   total = 0
   target = 50
   while total < target:
       print(f"Amount Due: {target - total}")
       coin = getcoin()
       if coin in [5,10,25]:
         total += coin
       else:
         continue

       if target > total:
        print(f"Amount Due: {target - total}")
   print(f"Change Owed: {total - target}")

def getcoin():
  while True:
   coin = int(input("Insert Coin:"))
   return coin
   break

main()

import fuel
from fuel import gauge,convert

def test_e():
    assert gauge(1) == 'E'
def test_f():
    assert gauge(99) == 'F'
def test_perc():
    assert gauge(25) == '25%'
    assert gauge(50) == '50%'

def test_convert():
    assert convert('1/4') == 25

    assert convert('2/4') == 50

    assert convert('1/1') == 100

def test_conver_errors():
    try:
        convert('4/3')
        assert False, 'Expected value error for x/y'
    except ValueError:
        pass
    try:
        convert('0/0')
        assert False, 'Expected zero division error for dividing by zero'
    except ZeroDivisionError:
        pass
    try:
        convert('-4/2')
        assert False, 'Expected value error for negative fraction'
    except ValueError:
        pass

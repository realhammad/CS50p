g_list = {}

while True:
    try:
        item = input().upper().strip()
        if item not in g_list:
           g_list[item] = 1
        else:
            g_list[item] += 1

    except EOFError:
        print()
        sorted_list = dict(sorted(list(g_list.items())))
        for item in sorted_list:
            print(sorted_list[item],item, sep = " ")
        break
    except KeyError:
        pass



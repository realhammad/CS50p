#In a file called camel.py, implement a program that prompts the user
# for the name of a variable in camel case and outputs the corresponding name in snake case.
# Assume that the user’s input will indeed be in camel case.
def main():
 camelCase = input("camelCase:")
 camel_to_snake(camelCase)
 print()

def camel_to_snake(camelCase):
      for letter in camelCase:
        if letter.isupper():
            print("_" + letter.lower(), end = "")
        else:
           print(letter, end = "")

main()

import sys
import inflect
from datetime import datetime, time, date

def main():
    dob = input("Date of birth: ").strip()
    work(dob)
def work(dob):
    if not check_validity(dob):
        sys.exit("Invalid Format")

    dob_date = datetime.strptime(dob, '%Y-%m-%d')
    dob_date = datetime.combine(dob_date.date(), time(0, 0, 0))

    td = todays_date()

    if dob_date > td:
        sys.exit("Date of birth cannot be in the future")

    time_diff = td - dob_date

    total_minutes = time_diff.total_seconds() / 60

    p = inflect.engine()
    minutes_in_words = p.number_to_words(int(total_minutes), andword='')
    minutes_in_words = minutes_in_words[0].upper() + minutes_in_words[1:] + ' minutes'
    print(minutes_in_words)

def todays_date():
    today = date.today()
    todays_date = datetime.combine(today, time(0, 0, 0))
    return todays_date

def check_validity(dob):
    try:
        datetime.strptime(dob, '%Y-%m-%d')
        return True
    except ValueError:
        return False

if __name__ == "__main__":
    main()

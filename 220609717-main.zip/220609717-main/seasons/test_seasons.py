from seasons import work,check_validity
import seasons
def test_working():
    assert work("1990-01-01") != 'Eighteen million, seven hundred sixty-three thousand, two hundred minutes'
def test_checkvalidation():
    assert check_validity("1999-12-22") == True


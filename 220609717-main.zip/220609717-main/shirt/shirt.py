import sys
import PIL
from PIL import Image
#Two command line arguments
if len(sys.argv)>3:
    sys.exit("Too many command-line arguments.")
if len(sys.argv)<3:
    sys.exit("Too less command-line arguments.")
if  sys.argv[1].endswith('.jpg') and sys.argv[1].endswith('.jpg')!= sys.argv[2].endswith('.jpg') :
    sys.exit("Invalid Output")
if sys.argv[1].endswith('.png') != sys.argv[2].endswith('.png'):
    sys.exit("Invalid Output")
if sys.argv[1].endswith('.jpeg') != sys.argv[2].endswith('.jpeg'):
    sys.exit("Invalid Output")

input_image = sys.argv[1]
output_image = sys.argv[2]

try :
     image = Image.open(input_image)
     shirt = Image.open("shirt.png")
     size = shirt.size

     muppet = PIL.ImageOps.fit(image,size)
     muppet.paste(shirt,shirt)
     muppet.save(output_image)



except FileNotFoundError:
    sys.exit("Invalid input")



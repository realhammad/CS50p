from bank import value

def test_hey_hello():
    assert value("Hello") == 0

def test_h():
    assert value("How are you sir") == 20

def test_nogreeting():
    assert value("Goodmorning sir") == 100
